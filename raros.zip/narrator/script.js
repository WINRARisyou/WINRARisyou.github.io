var anger = 0
var stage = 0
var pText = null
function addAnger() {
	// you know this is old when you see i misspelled multiplier.
  if (multiplyer === 0) {
    var multiplyer = 1
  }
  var anger = anger * multiplyer;
  var multiplyer = 0;
  alert(anger);
  if (anger >= 100) {
    var p = document.createElement("p");
    p.innerText = ">THATS IT I HAVE HAD ENOUGH! YOU COMPUTER IS DEAD";
    p.setAttribute('class', 'gameText');
    document.body.appendChild(p);
  }
};
function start_demise() {
    pText = "'We're going to have a little quiz'"
    para();
    pText = "'What is 1 + 1?'"
    para();
}
function para(text) {
    var p = document.createElement("p");
    p.innerHTML = text;
    p.setAttribute('class', 'gameText');
    document.body.appendChild(p);
}
function textbox() {
    var input = document.createElement("input");
    input.setAttribute('class', 'gameInput');
    input.setAttribute('id', 'text');
    document.body.appendChild(input);
    var inputCheck = document.createElement("button");
    inputCheck.setAttribute('onclick', 'getVal();');
    inputCheck.setAttribute('id', 'blank-space');
    inputCheck.setAttribute('class', 'getVal');
    document.body.appendChild(inputCheck);
}
function getVal() {
  // Selecting the input element and get its value 
  var inputVal = document.getElementById("text").value;          
  // Displaying the value
  if (inputVal === "noescape.html" && stage === 0) {
  var p = document.createElement("p");
  p.innerText = ">So you have choosen death? (Yes/No)";
  p.setAttribute('class', 'gameText');
  document.body.appendChild(p);
  document.getElementById("text").remove()
  document.getElementById("blank-space").remove()
  textbox();
  stage += 1;
  addAnger();
  //alert(stage)
  } 
  if (inputVal === "no" && stage === 1) {
    pText = "Too bad";
    para(pText);
    start_demise()
    alert('yeah me and my friend didn\'t really get that far into this, so after this its broken.')
    start_demise();
    pText = "I was inspired by BenBonk and his video about creating a game where the narrator would get progressivly more annoyed the more questions you got wrong. I was also kinda isnpired by \"There is no Game: Jam Edition\" from 2015. I remember loving that one. Anyway, I may end up revisitng and finishing this someday.";
    para(pText);
  } else if (inputVal.toLowerCase() === "yes") {
      pText = "Perfect.";
      para(pText);
      alert('yeah me and my friend didn\'t really get that far into this, so after this its broken.')
      start_demise();
      pText = `Hello! I was inspired by BenBonk and his video about <a href='https://www.youtube.com/watch?v=Ck2_uuIZczM'>creating a game where the narrator would get progressivly more annoyed the more questions you got wrong</a>. I was also inspired by <a href='https://www.construct.net/en/free-online-games/game-174/play'>"There is no Game: Jam Edition"</a> from 2015. I remember loving that one. Anyway, I may end up revisitng and finishing this someday.`;
      para(pText);
  }
  if (inputVal !== 1 && stage === 2) {
    addAnger();
    start_demise();
  }
}
